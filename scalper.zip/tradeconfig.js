// Trade configuration for backtesting
export const tradeConfig = {
    // Trade direction ('buy' or 'sell')
    direction: 'buy',

    // Profit and loss settings (in %)
    takeProfit: 0.2,    // Take profit at 1.5%
    stopLoss: 1.5,      // Stop loss at 2%

    // Leverage multiplier
    leverage: 50,        // 1x leverage (spot trading)

    // Trading fees
    totalMakerFee: 0.04, // 0.04% maker fee

    // Capital settings
    initialCapital: 100,  // Starting capital in USDT
    riskPerTrade: 100    // Percentage of capital to risk per trade (100 = full capital)
};