// backtestWithEdges.js
import {
    api,
    time as interval,
    symbol,
    limit,
    minSwingPct,
    shortWindow,
    longWindow,
    confirmOnClose,
    minLegBars
} from './config/config.js';

import { loadPivotData } from './utils/pivotCache.js';
import { BacktestStats } from './utils/backtest/backtestStats.js';
import BacktestEngineWithEdges from './utils/backtest/backtestEngineWithEdges.js';
import { BacktestExporter } from './utils/backtest/backtestExporter.js';
import { ConsoleLogger } from './utils/backtest/consoleLogger.js';
import { tradeConfig } from './config/tradeconfig.js';

// Create pivot config from imported values
const pivotConfig = {
    minSwingPct,
    shortWindow,
    longWindow,
    confirmOnClose,
    minLegBars
};

// Edge display formatting
function formatEdgeInfo(edges) {
    if (!edges) return '';
    
    const formatTimeframe = (tf, edge) => {
        if (!edge) return '';
        const direction = edge.direction === 'upper' ? 'to upper' : 'to lower';
        return `${tf}: ${edge.percentToEdge.toFixed(0)}% ${direction}`;
    };

    return Object.entries(edges)
        .map(([tf, edge]) => formatTimeframe(tf, edge))
        .filter(text => text)
        .join(' | ');
}

// Enhanced logger with edge information
class EdgeLogger extends ConsoleLogger {
    constructor() {
        super({ showPivot: true, showLimits: true });
    }

    formatPivotLog(pivot) {
        const baseLog = super.formatPivotLog(pivot);
        const edgeInfo = pivot.edges ? `
EDGES: ${formatEdgeInfo(pivot.edges)}` : '';
        return baseLog + edgeInfo;
    }

    logPivot(pivot) {
        if (this.performanceMode) return;
        console.log(this.formatPivotLog(pivot));
    }

    logInitialConfig(symbol, interval, api, tradeConfig) {
        super.logInitialConfig(symbol, interval, api, tradeConfig);
        console.log('Edge Analysis: Enabled');
        console.log('');
    }

    logCacheStatus(found) {
        if (this.performanceMode) return;
        if (found) {
            console.log('✓ Found cached pivot data');
        } else {
            console.log('❌ No cached pivot data found');
        }
    }

    logError(message) {
        console.error('❌ ' + message);
    }

    log(message) {
        if (this.performanceMode) return;
        console.log(message);
    }

    logStats(stats) {
        if (this.performanceMode) return;
        console.log('\nBacktest Results:');
        console.log(`Total Trades: ${stats.totalTrades}`);
        console.log(`Winning Trades: ${stats.winningTrades}`);
        console.log(`Losing Trades: ${stats.losingTrades}`);
        console.log(`Win Rate: ${(stats.winRate * 100).toFixed(2)}%`);
        console.log(`Average Win: ${stats.averageWin.toFixed(2)}%`);
        console.log(`Average Loss: ${stats.averageLoss.toFixed(2)}%`);
        console.log(`Final Capital: $${stats.finalCapital.toFixed(2)}`);
        console.log(`Total Return: ${stats.totalReturn.toFixed(2)}%`);
    }

    logLimitOrder(type, price, pivot) {
        if (this.performanceMode) return;
        const baseLog = `Setting ${type} limit @ ${price.toFixed(2)}`;
        let edgeWarning = '';

        if (pivot.edges) {
            // Check if we're near any edges (>80%)
            const nearEdges = Object.entries(pivot.edges)
                .filter(([_, edge]) => edge.percentToEdge > 80)
                .map(([tf, edge]) => `${tf} ${edge.direction} (${edge.percentToEdge.toFixed(0)}%)`);

            if (nearEdges.length > 0) {
                edgeWarning = `
CAUTION - Near edges: ${nearEdges.join(', ')}`;
            }
        }

        console.log(baseLog + edgeWarning);
    }
}

async function runBacktest() {
    const logger = new EdgeLogger();

    // Initialize logger with config
    logger.logInitialConfig(symbol, interval, api, tradeConfig);

    // Load cached pivot data
    const cachedData = await loadPivotData(symbol, interval);

    if (cachedData && cachedData.pivots && cachedData.metadata?.edgeAnalysis) {
        logger.logCacheStatus(true);
        logger.logFetchDetails(cachedData.pivots, cachedData.pivots.length, 0);
    } else {
        logger.logError('No edge-enhanced pivot data found. Please run generateEdgePivots.js first.');
        process.exit(1);
    }

    // Initialize components with enhanced logger
    const engine = new BacktestEngineWithEdges(pivotConfig, tradeConfig, logger);
    const exporter = new BacktestExporter({
        saveJson: tradeConfig.saveToFile,
        saveCsv: tradeConfig.saveToFile,
        config: tradeConfig
    }, { config: tradeConfig });

    // Run backtest with pivot data
    const results = await engine.runBacktest(cachedData.pivots);
    
    // Calculate and display statistics
    const stats = engine.calculateStats();
    logger.logStats(stats);

    // Export results if configured
    if (tradeConfig.saveToFile) {
        await exporter.exportResults(results, stats);
    }

    return { results, stats };
}

// Run if called directly
if (process.argv[1] === new URL(import.meta.url).pathname) {
    runBacktest().catch(error => {
        console.error('Error running backtest:', error);
        console.error(error.stack);
    });
}

export default runBacktest;
