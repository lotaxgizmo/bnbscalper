// backtestEngineWithEdges.js
import BacktestEngine from './backtestEngine.js';

class BacktestEngineWithEdges extends BacktestEngine {
    constructor(pivotConfig, tradeConfig, logger) {
        super(pivotConfig, tradeConfig, logger);
    }

    // Override order placement to include edge checks
    async placeLimitOrder(type, price, pivot) {
        // Log with edge information
        this.logger.logLimitOrder(type, price, pivot);

        // Check if we're near any dangerous edges (>90%)
        if (pivot.edges) {
            const dangerousEdges = Object.values(pivot.edges)
                .filter(edge => edge.percentToEdge > 90);

            if (dangerousEdges.length > 0) {
                this.logger.log('WARNING: Placing order very close to market edge');
            }
        }

        // Proceed with normal order placement
        return super.placeLimitOrder(type, price, pivot);
    }

    // Override pivot processing to include edge information
    processPivot(pivot) {
        // Log pivot with edge information
        this.logger.logPivot(pivot);
        
        // Continue with normal pivot processing
        return super.processPivot(pivot);
    }
}

export default BacktestEngineWithEdges;
